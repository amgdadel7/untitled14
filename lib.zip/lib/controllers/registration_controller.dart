import 'package:untitled14/services/api_service.dart';

import '../services/device_service.dart';
import '../services/location_service.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class RegistrationController {
  static final LocalDatabaseService _localDb = LocalDatabaseService();

  static Future<void> handleRegistration({
    required String countryCode,
    required String phoneNumber,
    required Function(String) onError,
  }) async {
    try {
      final uuid = await DeviceService.getUniqueId();
      print('📱 UUID: $uuid');

      // 1. إرسال إلى API
      final apiSuccess = await ApiService.sendDeviceInfo(
        uuid: uuid,
        code: countryCode,
        phoneNum: phoneNumber,
      );
      if (!apiSuccess) throw Exception('فشل إرسال البيانات إلى الخادم');

      // 2. الحفظ المحلي
      await _localDb.upsertDeviceInfo(
        uuid: uuid,
        code: countryCode,
        phoneNum: phoneNumber,
      );

    } catch (e) {
      onError('⚠️ خطأ: ${e.toString()}');
    }
  }
}
class LocalDatabaseService {
  static const _databaseName = 'local_device.db';
  static const _databaseVersion = 1;

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final path = join(await getDatabasesPath(), _databaseName);
    return openDatabase(
      path,
      version: _databaseVersion,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE device_info (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        uuid TEXT UNIQUE NOT NULL,
        code TEXT NOT NULL,
        phone_num TEXT UNIQUE NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    ''');
    print('تم إنشاء جدول SQLite المحلي');
  }

  Future<void> upsertDeviceInfo({
    required String uuid,
    required String code,
    required String phoneNum,
  }) async {
    try {
      final db = await database;
      await db.insert(
        'device_info',
        {
          'uuid': uuid,
          'code': code,
          'phone_num': phoneNum,
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
      print('✅ تم حفظ/تحديث البيانات محليًا');
    } catch (e) {
      print('❌ خطأ في الحفظ المحلي: ${e.toString()}');
      throw Exception('فشل في الحفظ المحلي');
    }
  }
}