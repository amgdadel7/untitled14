import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:untitled14/utils/country_code_utils.dart';
import 'package:untitled14/utils/validators.dart';
import '../widgets/country_picker_field.dart';
import '../controllers/registration_controller.dart';
import '../services/location_service.dart';
import '../controllers/first_launch_manager.dart';

class RegistrationScreen extends StatefulWidget {
  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final _formKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();
  String _countryCode = 'EG';
  bool _isLoading = false;

  Future<void> _handleSubmit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      await RegistrationController.handleRegistration(
          countryCode: '+${CountryCodeUtils.getPhoneCode(_countryCode)}',
          phoneNumber: _phoneController.text,
          onError: (error) => ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error: $error')),
          ));

          // تحديث حالة الإطلاق الأولي
          await Provider.of<FirstLaunchManager>(context, listen: false)
          .completeRegistration();

      // الانتقال إلى الشاشة الرئيسية
      Navigator.pushReplacementNamed(context, '/home');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Phone Registration')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              CountryPickerField(
                countryCode: _countryCode,
                onCountrySelected: (country) => setState(() {
                  _countryCode = country.countryCode;
                }),
              ),
              TextFormField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(
                  labelText: 'Phone Number',
                  prefix: Text('+${CountryCodeUtils.getPhoneCode(_countryCode)} '),
                ),
                validator: (value) => Validators.validatePhoneNumber(value),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _isLoading ? null : _handleSubmit,
                child: _isLoading
                    ? CircularProgressIndicator()
                    : Text('Start'),
              ),
              TextButton(
                onPressed: () async {
                  final code = await LocationService.getCountryCodeByGPS();
                  if (code != null) setState(() => _countryCode = code);
                },
                child: Text('Detect Country via GPS'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}